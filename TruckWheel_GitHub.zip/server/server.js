require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
  origin: ['http://localhost:3001', 'http://localhost:5173', 'http://localhost:3306', 'http://localhost:3000'],
  credentials: true
}));
app.use(express.json());

// Simple test route
app.get('/', (req, res) => {
  console.log('Root route accessed');
  res.send('Server is running - ' + new Date().toISOString());
});

// Simple auth check endpoint (for compatibility)
app.get('/api/auth/check', (req, res) => {
  res.json({ isAuthenticated: false });
});

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'reacttruckwheel',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

// Seller login endpoint
app.post('/api/seller/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required' });
    }

    // Find user by email
    const [users] = await pool.query('SELECT * FROM seller WHERE email = ?', [email]);
    
    if (users.length === 0) {
      return res.status(404).json({ success: false, error: 'No account found with this email' });
    }

    const user = users[0];
    
    // Compare passwords using bcrypt
    const isPasswordValid = await bcrypt.compare(password, user.password);
    
    if (!isPasswordValid) {
      console.log('Password comparison failed');
      return res.status(401).json({ success: false, error: 'Invalid password' });
    }

    // Remove sensitive data from response
    const { password: _, ...userData } = user;
    
    res.json({ 
      success: true, 
      message: 'Login successful',
      user: userData
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      success: false,
      error: 'Internal server error' 
    });
  }
});

// Create buyers table if it doesn't exist
const createBuyersTable = async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS buyers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        phone VARCHAR(20) NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
    console.log('Buyers table verified/created');
  } catch (error) {
    console.error('Error creating buyers table:', error);
  }
};

// Initialize database tables
createBuyersTable();

// Test database connection and tables
app.get('/api/test-db', async (req, res) => {
  if (process.env.NODE_ENV !== 'development') {
    return res.status(404).json({ error: 'Not found' });
  }
  try {
    // Test connection
    const connection = await pool.getConnection();
    console.log('Database connection successful');
    
    // Check if database exists
    const [dbs] = await connection.query('SHOW DATABASES LIKE ?', [process.env.DB_NAME || 'reacttruckwheel']);
    if (dbs.length === 0) {
      return res.status(500).json({ 
        error: 'Database not found',
        message: 'The configured database does not exist'
      });
    }
    
    // Check if tables exist
    const [tables] = await connection.query("SHOW TABLES");
    const tableNames = tables.map(t => Object.values(t)[0]);
    
    // Check structure of each table
    const tableStructures = {};
    for (const table of tableNames) {
      const [structure] = await connection.query(`DESCRIBE ${table}`);
      const [data] = await connection.query(`SELECT * FROM ${table} LIMIT 5`);
      tableStructures[table] = { structure, data };
    }
    
    connection.release();
    
    res.json({
      database: process.env.DB_NAME || 'reacttruckwheel',
      connection: 'Successful',
      tables: tableNames,
      tableStructures
    });
    
  } catch (error) {
    console.error('Database test error:', error);
    res.status(500).json({
      error: 'Database connection failed',
      message: error.message,
      code: error.code
    });
  }
});

// Buyer login endpoint
app.post('/api/buyer/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required' });
    }

    // Find buyer by email
    const [buyers] = await pool.query('SELECT * FROM buyers WHERE email = ?', [email]);
    
    if (buyers.length === 0) {
      return res.status(404).json({ success: false, error: 'No account found with this email' });
    }

    const buyer = buyers[0];
    
    // Compare passwords using bcrypt
    const isPasswordValid = await bcrypt.compare(password, buyer.password);
    
    if (!isPasswordValid) {
      return res.status(401).json({ success: false, error: 'Invalid password' });
    }

    // Remove password from response
    const { password: _, ...userData } = buyer;
    
    res.json({
      success: true,
      message: 'Login successful',
      user: userData
    });

  } catch (error) {
    console.error('Buyer login error:', error);
    res.status(500).json({ 
      success: false,
      error: 'Internal server error' 
    });
  }
});

// Simple logout endpoint (handled by frontend, but kept for compatibility)
app.post('/api/auth/logout', (req, res) => {
  res.json({ success: true, message: 'Logged out successfully' });
});

// Get buyer by ID
app.get('/api/buyer/:id', async (req, res) => {
  try {
    const [buyer] = await pool.query(
      'SELECT id, name, email, phone, created_at FROM buyers WHERE id = ?',
      [req.params.id]
    );
    
    if (buyer.length === 0) {
      return res.status(404).json({ success: false, error: 'Buyer not found' });
    }
    
    res.json({ success: true, user: buyer[0] });
  } catch (error) {
    console.error('Error fetching buyer:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// Get seller by ID
app.get('/api/seller/:id', async (req, res) => {
  try {
    const [seller] = await pool.query(
      'SELECT id, name, email, phone, created_at FROM seller WHERE id = ?',
      [req.params.id]
    );
    
    if (seller.length === 0) {
      return res.status(404).json({ success: false, error: 'Seller not found' });
    }
    
    res.json({ success: true, user: seller[0] });
  } catch (error) {
    console.error('Error fetching seller:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// Buyer registration endpoint
app.post('/api/buyer/register', async (req, res) => {
  console.log('Received buyer registration request:', req.body);
  
  try {
    const { name, email, phone, password } = req.body;
    
    // Basic validation
    if (!name || !email || !phone || !password) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Check if email already exists
    const [existingBuyer] = await pool.query(
      'SELECT * FROM buyers WHERE email = ?', 
      [email]
    );

    if (existingBuyer && existingBuyer.length > 0) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // Hash password
    const hashedPassword = await require('bcrypt').hash(password, 10);

    // Insert new buyer
    const [result] = await pool.query(
      'INSERT INTO buyers (name, email, phone, password) VALUES (?, ?, ?, ?)',
      [name, email, phone, hashedPassword]
    );

    // Set session
    req.session.userId = result.insertId;
    req.session.userType = 'buyer';
    req.session.save();

    // Get the newly created buyer (without password)
    const [buyer] = await pool.query(
      'SELECT id, name, email, phone, created_at FROM buyers WHERE id = ?',
      [result.insertId]
    );

    res.status(201).json({
      message: 'Buyer registered successfully',
      user: buyer[0]
    });

  } catch (error) {
    console.error('Buyer registration error:', error);
    res.status(500).json({ 
      error: 'An error occurred during registration',
      details: error.message 
    });
  }
});

// Seller registration endpoint
app.post('/api/seller/register', async (req, res) => {
  console.log('Received registration request:', req.body);
  
  try {
    const { name, email, phone, password } = req.body;
    
    // Basic validation
    if (!name || !email || !phone || !password) {
      console.log('Validation failed - missing fields');
      return res.status(400).json({ 
        error: 'All fields are required',
        received: { name: !!name, email: !!email, phone: !!phone, password: '***' }
      });
    }

    // Check database connection
    try {
      await pool.getConnection();
      console.log('Database connection successful');
    } catch (dbError) {
      console.error('Database connection error:', dbError);
      return res.status(500).json({ 
        error: 'Database connection failed',
        details: dbError.message 
      });
    }

    try {
      // Check if email already exists
      const [existingSeller] = await pool.query(
        'SELECT * FROM seller WHERE email = ?', 
        [email]
      );
      console.log('Existing seller check:', existingSeller);

      if (existingSeller && existingSeller.length > 0) {
        return res.status(400).json({ error: 'Email already registered' });
      }

      // Hash password (using bcrypt)
      console.log('Hashing password...');
      const hashedPassword = await require('bcrypt').hash(password, 10);

      // Insert new seller
      console.log('Inserting new seller...');
      const [result] = await pool.query(
        'INSERT INTO seller (name, email, phone, password) VALUES (?, ?, ?, ?)',
        [name, email, phone, hashedPassword]
      );
      console.log('Insert result:', result);

      res.status(201).json({
        message: 'Seller registered successfully',
        sellerId: result.insertId
      });
    } catch (queryError) {
      console.error('Database query error:', queryError);
      return res.status(500).json({ 
        error: 'Database operation failed',
        details: queryError.message,
        code: queryError.code
      });
    }
  } catch (error) {
    console.error('Unexpected error in registration:', error);
    res.status(500).json({ 
      error: 'Internal server error',
      details: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

// Logout endpoint
app.post('/api/seller/logout', (req, res) => {
  try {
    // In a real app with sessions, you would destroy the session here
    // For now, we'll just send a success response
    res.json({ message: 'Logout successful' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Start the server
const startServer = async () => {
  try {
    // First try the default port, if busy try any available port
    const server = app.listen(PORT, '0.0.0.0', () => {
      const actualPort = server.address().port;
      console.log(`\n=== Server Started ===`);
      console.log(`Server running at: http://localhost:${actualPort}`);
      console.log(`Test routes:`);
      console.log(`- http://localhost:${actualPort}/`);
      console.log(`- http://localhost:${actualPort}/api/test-db\n`);
    });

    server.on('error', (error) => {
      if (error.code === 'EADDRINUSE') {
        console.error(`Port ${PORT} is already in use. Trying a different port...`);
        // Try any available port
        const newServer = app.listen(0, '0.0.0.0', () => {
          const newPort = newServer.address().port;
          console.log(`\n=== Server Started on Alternative Port ===`);
          console.log(`Server running at: http://localhost:${newPort}`);
          console.log(`Test routes:`);
          console.log(`- http://localhost:${newPort}/`);
          console.log(`- http://localhost:${newPort}/api/test-db\n`);
        });
      } else {
        console.error('Server error:', error);
      }
    });
  } catch (error) {
    console.error('Failed to start server:', error);
  }
};

startServer();